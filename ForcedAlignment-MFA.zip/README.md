# ForcedAlignment-MFA

This repository contains setup and scripts for performing forced alignment using Montreal Forced Aligner (MFA).