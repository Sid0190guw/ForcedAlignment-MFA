#!/bin/bash
# Placeholder script to run forced alignment