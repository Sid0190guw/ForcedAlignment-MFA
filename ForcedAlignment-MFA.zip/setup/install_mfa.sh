#!/bin/bash
# Placeholder script to install Montreal Forced Aligner