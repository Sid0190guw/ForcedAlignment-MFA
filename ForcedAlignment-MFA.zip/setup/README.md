# Setup Instructions

This folder contains instructions to install MFA.